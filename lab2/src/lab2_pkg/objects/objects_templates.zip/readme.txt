You can replace this parameters to the object_pose_publisher.py file

OBJECT_TEMPLATES = {
    ObjectTemplate(name='gearbox', ar_marker='ar_marker_1', t_ar_obj=[-0.06745, -0.06195, 0.056]),
    ObjectTemplate(name='nozzle', ar_marker='ar_marker_1', t_ar_obj=[0.10085, -0.0575, 0.032]),
    ObjectTemplate(name='pawn', ar_marker='ar_marker_1', t_ar_obj=[-0.05075, -0.0665, 0.091])
}

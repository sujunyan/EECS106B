This is the Cython-coded accelerator module for PyOpenGL 3.x
